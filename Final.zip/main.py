## The commented lines can be uncommented for training purposes ONLY.
#import parse
#print("Finished parsing(training)")
#import score_train
#print("Finished scoring(training)")
#import composer
#print("Finished composing(training)")
import prediction
